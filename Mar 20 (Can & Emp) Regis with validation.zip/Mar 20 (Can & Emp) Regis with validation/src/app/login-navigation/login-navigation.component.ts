import { Component, OnInit } from '@angular/core';
import { RouterModule, Routes  } from '@angular/router';
import { CandidateRegisComponent } from "src/app/candidate-regis/candidate-regis.component";
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";


@Component({
  selector: 'app-login-navigation',
  templateUrl: './login-navigation.component.html',
  styleUrls: ['./login-navigation.component.css']
})

export class LoginNavigationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
