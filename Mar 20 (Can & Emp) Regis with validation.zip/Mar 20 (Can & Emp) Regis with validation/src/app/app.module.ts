// import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule, Title } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FooterComponent } from './footer/footer.component';
import { NavComponent } from './nav/nav.component';
import { LoginNavigationComponent } from './login-navigation/login-navigation.component';
import { CandidateRegisComponent } from './candidate-regis/candidate-regis.component';
import { EmployeeLoginComponent } from './employee-login/employee-login.component';
import { EmployeeRegisComponent } from './employee-regis/employee-regis.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { EmpViewScoreComponent } from './emp-view-score/emp-view-score.component';
import { AdminEmpScoreComponent } from './admin-emp-score/admin-emp-score.component';
import { AdminCandidateScoreComponent } from './admin-candidate-score/admin-candidate-score.component';
import { SkillSetComponent } from './skill-set/skill-set.component';
import { TestPageComponent } from './test-page/test-page.component';
import { ReportGenerationComponent } from './report-generation/report-generation.component';
import { AccessSettingComponent } from './access-setting/access-setting.component';
import { ProfileUploadComponent } from './profile-upload/profile-upload.component';
import { QuestionUploadComponent } from './question-upload/question-upload.component';
import { AddQuestionComponent } from './add-question/add-question.component';
import { ManageQuestionComponent } from './manage-question/manage-question.component';
import { HttpClientModule } from '@angular/common/http'; 
import { CandidateService } from "src/app/DataServices/candidate-service";
import { EmployeeService } from "src/app/DataServices/employee-service";
import { SidebarComponent } from './sidebar/sidebar.component';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    NavComponent,
    LoginNavigationComponent,
    CandidateRegisComponent,
    EmployeeLoginComponent,
    EmployeeRegisComponent,
    ForgotPasswordComponent,
    EmpViewScoreComponent,
    AdminEmpScoreComponent,
    AdminCandidateScoreComponent,
    SkillSetComponent,
    TestPageComponent,
    ReportGenerationComponent,
    AccessSettingComponent,
    ProfileUploadComponent,
    QuestionUploadComponent,
    AddQuestionComponent,
    ManageQuestionComponent,
    SidebarComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgbModule,
    BrowserAnimationsModule
    
  ],
  providers: [EmployeeService,CandidateService, Title],
  bootstrap: [AppComponent]
})
export class AppModule { }
