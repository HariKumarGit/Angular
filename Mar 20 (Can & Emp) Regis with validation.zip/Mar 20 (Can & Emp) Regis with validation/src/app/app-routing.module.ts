import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginNavigationComponent } from "src/app/login-navigation/login-navigation.component";
import { CandidateRegisComponent } from "src/app/candidate-regis/candidate-regis.component";
import { EmployeeLoginComponent } from "src/app/employee-login/employee-login.component";
import { EmployeeRegisComponent } from "src/app/employee-regis/employee-regis.component";
import { ReportGenerationComponent } from "src/app/report-generation/report-generation.component";
import { ProfileUploadComponent } from "src/app/profile-upload/profile-upload.component";
import { AccessSettingComponent } from "src/app/access-setting/access-setting.component";
import { ForgotPasswordComponent } from "src/app/forgot-password/forgot-password.component";
import { SkillSetComponent } from "src/app/skill-set/skill-set.component";
import { SidebarComponent } from "src/app/sidebar/sidebar.component";
import { ManageQuestionComponent } from "src/app/manage-question/manage-question.component";
import { QuestionUploadComponent } from "src/app/question-upload/question-upload.component";
import { AddQuestionComponent } from "src/app/add-question/add-question.component";


const routes: Routes = [
  {
    path: '', component: LoginNavigationComponent
  },
  {
    path: 'login-navigation', component: LoginNavigationComponent
  },
  {
    path: 'candidate-regis', component: CandidateRegisComponent
  },
  {
    path: 'employee-login', component: EmployeeLoginComponent
  },
  {
    path: 'employee-regis', component: EmployeeRegisComponent
  },
  {
    path: 'profile-upload', component: ProfileUploadComponent
  },
  {
    path: 'access-setting', component: AccessSettingComponent
  },
  {
    path: 'report-generation', component: ReportGenerationComponent
  },
  {
    path: 'forgot-password', component: ForgotPasswordComponent
  },
  {
    path: 'skill-set', component: SkillSetComponent
  },
  {
    path: 'app-sidebar', component: SidebarComponent
  },
  {
    path: 'manage-question', component: ManageQuestionComponent
  },
  {
    path: 'question-upload', component: QuestionUploadComponent
  },
  {
    path: 'add-question', component: AddQuestionComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
