import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-view-score',
  templateUrl: './emp-view-score.component.html',
  styleUrls: ['./emp-view-score.component.css']
})
export class EmpViewScoreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
