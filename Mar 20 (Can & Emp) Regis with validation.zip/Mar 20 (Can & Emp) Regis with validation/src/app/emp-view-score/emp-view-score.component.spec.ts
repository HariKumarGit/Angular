import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpViewScoreComponent } from './emp-view-score.component';

describe('EmpViewScoreComponent', () => {
  let component: EmpViewScoreComponent;
  let fixture: ComponentFixture<EmpViewScoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmpViewScoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpViewScoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
