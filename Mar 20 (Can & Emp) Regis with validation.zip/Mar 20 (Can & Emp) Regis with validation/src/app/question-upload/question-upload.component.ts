import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-question-upload',
  templateUrl: './question-upload.component.html',
  styleUrls: ['./question-upload.component.css']
})
export class QuestionUploadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
