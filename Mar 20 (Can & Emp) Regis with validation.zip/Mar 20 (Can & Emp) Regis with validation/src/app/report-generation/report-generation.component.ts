import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-generation',
  templateUrl: './report-generation.component.html',
  styleUrls: ['./report-generation.component.css']
})
export class ReportGenerationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
