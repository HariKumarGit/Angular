import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateRegisComponent } from './candidate-regis.component';

describe('CandidateRegisComponent', () => {
  let component: CandidateRegisComponent;
  let fixture: ComponentFixture<CandidateRegisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandidateRegisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidateRegisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
