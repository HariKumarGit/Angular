import { Component, OnInit, Host } from '@angular/core';
import { Candidate } from "src/app/ModuleFolder/candidate/candidate.model";
import { Router } from "@angular/router";
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule, Routes  } from '@angular/router';
import { CandidateService } from "src/app/DataServices/candidate-service";
import { ReportGenerationComponent } from "src/app/report-generation/report-generation.component";
// import { first } from 'rxjs/operators';
import { FormGroup } from "@angular/forms";
import { FormBuilder } from "@angular/forms";
import { HttpErrorResponse } from "@angular/common/http";
import { Employee } from "src/app/ModuleFolder/employee.model";
import { ResponseData } from "src/app/ModuleFolder/response-data.model";

@Component({
  selector: 'app-candidate-regis',
  templateUrl: './candidate-regis.component.html',
  styleUrls: ['./candidate-regis.component.css']
})

export class CandidateRegisComponent {
  
  candidate: Candidate = new Candidate;
  employee: Employee = new Employee;
  constructor(
    // private formBuilder: FormBuilder,
    private router: Router, 
    private candidService: CandidateService,
    
  
  ) {

  }
  createCandidate(): void {
    console.log("First Name " + this.candidate.firstName);
    var candidObj = JSON.stringify(this.candidate);
    console.log("Candidate Object  " + candidObj);
       
    this.candidService.createCandidate(this.candidate).subscribe(data => {
      let res=<ResponseData>data;
      
            if(res.statusDesc=="Candidate Registration is Successful"){
              alert("In component if "+res.statusDesc);
              this.router.navigate(['/skill-set']);
            }else{
              alert("In component Else "+res.statusDesc);
              // this.candidRegisForm.controls;
              this.router.navigate(['/login-navigation']);
            }


      // alert("Candidate created successfully.");
      // this.router.navigate(['/skill-set']);
    });
  };
// Create Employee 

  // createEmployee(): void {
  //   console.log("Emp Last Name " + this.employee.empLastName);
  //   var empObj = JSON.stringify(this.employee);
  //   console.log("Candidate Object  " + empObj);
    
    
  //   this.candidService.createEmployee(this.employee).subscribe(data => {
    
  //     alert("Candidate created successfully.");
  //     this.router.navigate(['/skill-set']);
  //   });
  // };
  // Create Employee end
  
  }
