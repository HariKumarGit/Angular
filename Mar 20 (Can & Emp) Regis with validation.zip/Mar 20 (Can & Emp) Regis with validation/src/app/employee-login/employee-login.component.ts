import { Component, OnInit } from '@angular/core';
import { Employee } from "src/app/ModuleFolder/employee.model";
import { FormBuilder } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
import { Router } from "@angular/router";

import { Validators } from "@angular/forms";
import { FormGroup } from "@angular/forms";
import { EmployeeService } from "src/app/DataServices/employee-service";
import { ResponseData } from "src/app/ModuleFolder/response-data.model";
// import { Observable } from "rxjs";
// import 'rxjs/add/observable/throw';
// import 'rxjs/add/operator/catch';
// import 'rxjs/add/operator/do';
// import 'rxjs/add/operator/map';

@Component({
  selector: 'app-employee-login',
  templateUrl: './employee-login.component.html',
  styleUrls: ['./employee-login.component.css']
})
export class EmployeeLoginComponent {
  empLoginForm: FormGroup;

  employee: Employee = new Employee;
  public res:ResponseData;
  // public emp[];
  // statusCode: string;


  constructor(
    private router: Router,
    private employeeService: EmployeeService,
  ) { }

  //   ngOnInit() {
  // this.empLoginForm=this.formBuilder.group({
  //   empBankId: ['', Validators.required],
  //   empPassword: ['', Validators.required]
  // });
  //   }
  empLogin(): void {
    console.log("Bank ID " + this.employee.empBankId);
    var candidObj = JSON.stringify(this.employee);
    console.log("Employee Object  " + candidObj);

    this.employeeService.emplLogin(this.employee).subscribe(data => {
      
      let res=<ResponseData>data;

      if(res.statusDesc!="Failure"){
        alert("In component if "+res.statusDesc);
        this.router.navigate(['/skill-set']);
      }else{
        alert("In component Else "+res.statusDesc);
        this.empLoginForm.controls;
        this.router.navigate(['/employee-login']);
      }

      // this.emp = data;
      // console.log('----->>>', this.emp);
      
      // this.router.navigate(['/app-sidebar']);

    });
    err => {
      console.log();
    }

  };

}
