import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent{
  title = 'eSEEApp';
}
export class Logger{
  log(msg: any) { console.log(msg);}
  error(msg: any) { console.log(msg);}
  warn(msg: any) { console.log(msg);}
  }

