import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminEmpScoreComponent } from './admin-emp-score.component';

describe('AdminEmpScoreComponent', () => {
  let component: AdminEmpScoreComponent;
  let fixture: ComponentFixture<AdminEmpScoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminEmpScoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminEmpScoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
