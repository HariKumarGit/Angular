import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-emp-score',
  templateUrl: './admin-emp-score.component.html',
  styleUrls: ['./admin-emp-score.component.css']
})
export class AdminEmpScoreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
