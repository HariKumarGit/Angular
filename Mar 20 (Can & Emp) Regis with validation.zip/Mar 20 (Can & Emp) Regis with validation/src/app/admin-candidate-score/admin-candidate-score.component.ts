import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-candidate-score',
  templateUrl: './admin-candidate-score.component.html',
  styleUrls: ['./admin-candidate-score.component.css']
})
export class AdminCandidateScoreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
