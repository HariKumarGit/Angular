import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminCandidateScoreComponent } from './admin-candidate-score.component';

describe('AdminCandidateScoreComponent', () => {
  let component: AdminCandidateScoreComponent;
  let fixture: ComponentFixture<AdminCandidateScoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminCandidateScoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminCandidateScoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
