import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-question',
  templateUrl: './manage-question.component.html',
  styleUrls: ['./manage-question.component.css']
})
export class ManageQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
