import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeRegisComponent } from './employee-regis.component';

describe('EmployeeRegisComponent', () => {
  let component: EmployeeRegisComponent;
  let fixture: ComponentFixture<EmployeeRegisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeRegisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeRegisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
