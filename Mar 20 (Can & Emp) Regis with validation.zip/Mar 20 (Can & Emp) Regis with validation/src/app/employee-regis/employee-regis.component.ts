import { Component, OnInit, Host } from '@angular/core';
import { Candidate } from "src/app/ModuleFolder/candidate/candidate.model";
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule, Routes } from '@angular/router';
import { CandidateService } from "src/app/DataServices/candidate-service";

import { Router } from "@angular/router";
import { FormGroup } from "@angular/forms";
import { FormBuilder } from "@angular/forms";
import { HttpErrorResponse } from "@angular/common/http";
import { Employee } from "src/app/ModuleFolder/employee.model";
import { SecurityQuest } from "src/app/ModuleFolder/security-quest.model";
import { EmployeeService } from "src/app/DataServices/employee-service";
import { map } from 'rxjs/operators';

import { Observable, pipe, merge } from 'rxjs';
import { concat } from "rxjs/internal/operators/concat";
import { ResponseData } from "src/app/ModuleFolder/response-data.model";


@Component({
  selector: 'app-employee-regis',
  templateUrl: './employee-regis.component.html',
  styleUrls: ['./employee-regis.component.css']
})
export class EmployeeRegisComponent {
  

  employee: Employee = new Employee;
  secquest: SecurityQuest=new SecurityQuest;
  


  constructor(
    private router: Router,
    private e: EmployeeService

  ) {

  }
  ngOnInit() {

  }


//Create Employee Post Service

   createEmployee(): void {
    this.employee.adminFlag = 'Y';
    // this.employee = Object.assign(this.employee, this.secquest);
    // this.employee.sec=this.secquest.secAns;
    // this.employee.sec=this.secquest.secQue;
    //angular.extend(this.employee,this.secquest);
    this.employee.secQue=this.secquest;
    
    console.log("Employee Object inside Emp Component "+JSON.stringify(this.employee));
  
  //   // console.log("Sec Ans  " + JSON.stringify(this.employee.secObj[0].secAns));
  //   var empObj = JSON.stringify(this.employee);
  //   console.log("Employee Along Securiy Object  " + empObj);

    this.e.createEmployee(this.employee).subscribe(data => {
      let res=<ResponseData>data;
      
            if(res.statusDesc=="Employee Registration success"){
              alert(res.statusDesc);
              this.router.navigate(['/skill-set']);
            }else{
              alert(res.statusDesc);
              this.router.navigate(['/employee-regis']);
            }
      // alert("Candidate created successfully.");
      // this.router.navigate(['/skill-set']);
    });
  };

//Create Employee Post Service End here 

}

