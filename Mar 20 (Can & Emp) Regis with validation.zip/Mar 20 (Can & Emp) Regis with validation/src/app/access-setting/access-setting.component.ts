import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-access-setting',
  templateUrl: './access-setting.component.html',
  styleUrls: ['./access-setting.component.css']
})
export class AccessSettingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
