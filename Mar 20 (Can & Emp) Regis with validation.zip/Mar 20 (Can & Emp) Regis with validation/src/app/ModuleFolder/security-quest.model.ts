
export class SecurityQuest {
    secQue:string;
    secAns:string;
    
}
