export class ResponseData {
    statusCode:string; 
    statusDesc:string; 
    data:any;
}
