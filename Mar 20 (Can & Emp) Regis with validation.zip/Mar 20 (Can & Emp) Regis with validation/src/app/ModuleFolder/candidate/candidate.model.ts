export class Candidate { 
  lastName:string;
  firstName:string;
  mobNo:string;
  dateOfBirth:string;
  eMail:string;
}
