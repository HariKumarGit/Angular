import { SecurityQuest } from "src/app/ModuleFolder/security-quest.model";



export class Employee {
empBankId:string;
empFirstName:string;
empLastName:string;
empDOB:string;
empEmail:string;
empMobNo:string;
empPassword:string;
adminFlag:string;
secQue:SecurityQuest;


}
