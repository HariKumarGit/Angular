import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-upload',
  templateUrl: './profile-upload.component.html',
  styleUrls: ['./profile-upload.component.css']
})
export class ProfileUploadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
