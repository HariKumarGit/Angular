import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Candidate } from "src/app/ModuleFolder/candidate/candidate.model";
import { HttpHeaders } from "@angular/common/http";
import { Employee } from "src/app/ModuleFolder/employee.model";

import { ResponseData } from "src/app/ModuleFolder/response-data.model";
import { map } from 'rxjs/operators';
import { pipe } from "rxjs";
import { Observable } from 'rxjs';


const httpOptions = {
    headers: new HttpHeaders({'Accept': 'application/json', 'Content-Type': 'application/json'})
     
  }

@Injectable({
    providedIn: 'root'
})



export class CandidateService {
   
    constructor(private http: HttpClient) { }


    // candidate: Candidate = new Candidate;
    // private candidObj = JSON.stringify(this.candidate);
    private userUrl = 'http://localhost:8080/eopsTestEngine/Login';
    // console.log("F Name"+Candidate.CanFirstName);
   // baseUrl: string = 'http://localhost:8080/';
    //private userUrl = '/api';

    createCandidate(candidate:Candidate) {
         console.log("Inside of can service " + candidate);
         console.log("Inside of can service Base URL " + this.userUrl);
         
        return this.http.post(`${this.userUrl}/CandidateRegister`, candidate,httpOptions).pipe(map(responseData => {
            if (responseData) {
                let response = <ResponseData>responseData;
                console.log("------->>>> " + JSON.stringify(response));
                console.log("------->>>> " + response.statusDesc);
                
                return <ResponseData>response;
        
    }

          
}));
    // getUsers() {
    //     return this.http.get<Candidate[]>(this.baseUrl);
    // }
//Create Emplyee Post 
//     createEmployee(employee:Employee) {
//         console.log("Inside of emp service " + JSON.stringify(employee));
//         console.log("Inside of emp service Base URL " + this.userUrl);
        
//        return this.http.post(`${this.userUrl}/EmployeeRegister`, employee,httpOptions)
       
//    }
}

}
