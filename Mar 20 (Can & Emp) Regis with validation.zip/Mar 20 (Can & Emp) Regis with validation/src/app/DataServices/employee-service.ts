import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { HttpHeaders } from "@angular/common/http";
import { Employee } from "src/app/ModuleFolder/employee.model";
import { HttpResponse } from "@angular/common/http";
import { ResponseData } from "src/app/ModuleFolder/response-data.model";
import { map } from 'rxjs/operators';
import { pipe } from "rxjs";
import { Observable } from 'rxjs';

const httpOptions = {
    headers: new HttpHeaders({ 'Accept': 'application/json', 'Content-Type': 'application/json' })
}  


@Injectable({
    providedIn: 'root'
})
export class EmployeeService {
    constructor(private http: HttpClient) { }
    private userUrl = 'http://localhost:8080/eopsTestEngine/Login';



    emplLogin(employee: Employee) {
        console.log("Inside of can service " + JSON.stringify(employee));
        console.log("Inside of can service Base URL " + this.userUrl);

        //    return this.http.post(`${this.userUrl}/EmployeeLogin`,employee,httpOptions)
        // this.http.post(`${this.userUrl}/EmployeeLogin`, employee,httpOptions).subscribe((res:HttpResponse<any>)=>{
        //     console.log(res.headers.get('Success in Login'));
        //     alert(res.status);

        return this.http.post(`${this.userUrl}/EmployeeLogin`, employee, httpOptions).pipe(map(responseData => {
            if (responseData) {
                let response = <ResponseData>responseData;
                console.log("------->>>> " + JSON.stringify(response));
                console.log("------->>>> " + response.statusDesc);
                
                return <ResponseData>response;
            
            }
           
        }));
    }

    createEmployee(employee: Employee): any {
        console.log("Inside of Employee service " + JSON.stringify(employee));
        console.log("Inside of Employee service Base URL " + this.userUrl);

        return this.http.post(`${this.userUrl}/EmployeeRegister`, employee, httpOptions).pipe(map(responseData => {
            if (responseData) {
                let response = <ResponseData>responseData;
                console.log("------->>>> " + JSON.stringify(response));
                console.log("------->>>> " + response.statusDesc);
                
                return <ResponseData>response;
            
            }
           
        }));
      }
    




}
    // return res;

